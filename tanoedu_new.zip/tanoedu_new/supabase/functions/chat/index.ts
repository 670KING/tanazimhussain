import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const OPENROUTER_API_KEY = Deno.env.get('OPENROUTER_API_KEY');

// ONLY user-specified free OpenRouter models
const FREE_TEXT_MODELS = [
  { id: 'gpt-oss-120b',     name: 'openai/gpt-oss-120b:free',         context: 131072 },
  { id: 'liquid-lfm',       name: 'liquid/lfm-2.5-1.2b-instruct:free', context: 32768 },
  { id: 'nemotron-ultra',   name: 'nvidia/nemotron-3-ultra-550b-a55b:free', context: 131072 },
  { id: 'nemotron-nano',    name: 'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:nitro', context: 65536 },
  { id: 'hy3-preview',      name: 'tencent/hy3-preview:free',         context: 131072 },
  { id: 'ling-2.6-1t',      name: 'inclusionai/ling-2.6-1t:free',     context: 131072 },
  { id: 'gemma-4-31b',      name: 'google/gemma-4-31b-it:free',       context: 131072 },
];

const FREE_VISION_MODELS = [
  { id: 'llama-nemotron-vl', name: 'nvidia/llama-nemotron-rerank-vl-1b-v2:free',             context: 8192 },
  { id: 'gemma-4-31b-vision', name: 'google/gemma-4-31b-it:free',                          context: 131072 },
  { id: 'nemotron-omni',      name: 'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free',  context: 128000 },
];

const MODEL_ALIASES: Record<string, string> = {};
for (const m of [...FREE_TEXT_MODELS, ...FREE_VISION_MODELS]) {
  MODEL_ALIASES[m.id] = m.name;
  MODEL_ALIASES[m.name] = m.name;
}

const VISION_MODEL_IDS = [
  ...FREE_VISION_MODELS.map(m => m.id),
  ...FREE_VISION_MODELS.map(m => m.name)
];

/**
 * Minimal safe HTML template used as a render fallback when the model
 * output fails validation/sanitization. Always renders to PDF.
 */
export function buildFallbackHtml(title: string, plainText: string): string {
  const safeTitle = (title || 'Document').replace(/[<>&]/g, (c) =>
    ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' } as Record<string, string>)[c]
  );
  // Split into paragraphs on blank lines, escape, wrap.
  const paragraphs = plainText
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) =>
      `<p>${p
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, ' ')}</p>`
    )
    .join('\n');
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${safeTitle}</title><style>@page{size:A4;margin:1in}body{font-family:"Times New Roman",serif;font-size:12pt;line-height:1.6;color:#000;margin:0}h1{text-align:center;font-size:20pt;margin-bottom:18px}p{text-align:justify;margin:0 0 10px;orphans:3;widows:3}</style></head><body><h1>${safeTitle}</h1>\n${paragraphs || '<p>No content available.</p>'}</body></html>`;
}

/**
 * Validate sanitized HTML for PDF rendering safety.
 * Returns { ok, reasons }. Any failure should trigger fallback rendering.
 */
export function validatePdfHtml(html: string): { ok: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (!html || html.length < 80) reasons.push('html-too-short');
  if (!/<!DOCTYPE\s+html/i.test(html)) reasons.push('missing-doctype');
  if (!/<html[\s>]/i.test(html) || !/<\/html>/i.test(html)) reasons.push('missing-html-tag');
  if (!/<body[\s>]/i.test(html) || !/<\/body>/i.test(html)) reasons.push('missing-body-tag');
  // Forbidden artifacts that survived the sanitizer
  if (/\\begin\{|\\end\{|\\frac|\\sqrt|\\sum|\\int/.test(html)) reasons.push('latex-artifact');
  if (/\$\$[^$]+\$\$|(?<!\w)\$[^$\n]+\$(?!\w)/.test(html)) reasons.push('dollar-math');
  if (/```/.test(html)) reasons.push('markdown-fence');
  if (/<table[\s>]/i.test(html)) reasons.push('forbidden-table');
  // Tag balance sanity check (rough): ensure roughly balanced < and >
  const opens = (html.match(/</g) || []).length;
  const closes = (html.match(/>/g) || []).length;
  if (Math.abs(opens - closes) > 2) reasons.push('tag-imbalance');
  return { ok: reasons.length === 0, reasons };
}

/**
 * Auto-balance section paragraph counts so the document fits a target
 * page range without overcrowding. Operates on the body of the HTML.
 * - short  : ~2-4 sections, max 2 paragraphs/section
 * - medium : ~4-6 sections, max 3 paragraphs/section
 * - long   : ~6-9 sections, max 4 paragraphs/section
 */
export function autoBalanceSections(html: string, length: 'short' | 'medium' | 'long' = 'medium'): string {
  const limits = {
    short:  { maxSections: 4, maxParas: 2, maxParaChars: 700 },
    medium: { maxSections: 6, maxParas: 3, maxParaChars: 900 },
    long:   { maxSections: 9, maxParas: 4, maxParaChars: 1100 },
  }[length];

  const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  if (!bodyMatch) return html;
  let body = bodyMatch[1];

  // Cap sections
  const sectionRegex = /<section\b[\s\S]*?<\/section>/gi;
  const sections = body.match(sectionRegex) || [];
  if (sections.length > limits.maxSections) {
    const kept = sections.slice(0, limits.maxSections).join('\n');
    // Remove all sections then prepend the kept ones in original order
    const nonSections = body.replace(sectionRegex, '').trim();
    body = `${nonSections}\n${kept}`;
  }

  // Cap paragraphs per section + split overlong paragraphs
  body = body.replace(sectionRegex, (sec) => {
    let s = sec;
    // Split overlong <p>…</p>
    s = s.replace(/<p>([\s\S]*?)<\/p>/gi, (_m, inner: string) => {
      const text = inner.trim();
      if (text.length <= limits.maxParaChars) return `<p>${text}</p>`;
      // Split on sentence boundaries roughly in half
      const sentences = text.split(/(?<=[.!?])\s+/);
      const mid = Math.ceil(sentences.length / 2);
      const a = sentences.slice(0, mid).join(' ');
      const b = sentences.slice(mid).join(' ');
      return `<p>${a}</p>\n<p>${b}</p>`;
    });
    // Cap paragraph count
    const paras = s.match(/<p>[\s\S]*?<\/p>/gi) || [];
    if (paras.length > limits.maxParas) {
      const keep = paras.slice(0, limits.maxParas).join('\n');
      const dropped = paras.slice(limits.maxParas);
      // Keep ULs and headings intact, just trim extra <p>
      s = s.replace(/<p>[\s\S]*?<\/p>/gi, '');
      // Insert kept paragraphs before </section>
      s = s.replace(/<\/section>/i, `\n${keep}\n</section>`);
      // Note dropped count for logging
      console.log(`[autoBalance] dropped ${dropped.length} extra paragraphs in a section`);
    }
    return s;
  });

  return html.replace(/<body[^>]*>[\s\S]*?<\/body>/i, `<body>${body}</body>`);
}

/**
 * Pre-output HTML sanitizer for PDF mode.
 * Strips LaTeX/markdown artifacts and replaces them with safe plain text.
 */
export function sanitizePdfHtml(raw: string): string {
  let html = raw.trim();

  // 1. Strip code fences (```html ... ```)
  html = html.replace(/^```(?:html)?\s*/i, '').replace(/```\s*$/i, '');

  // 2. Trim anything before <!DOCTYPE or <html
  const dt = html.search(/<!DOCTYPE\s+html/i);
  const ht = html.search(/<html[\s>]/i);
  const start = dt >= 0 ? dt : (ht >= 0 ? ht : -1);
  if (start > 0) html = html.slice(start);

  // 3. Trim trailing junk after </html>
  const endIdx = html.lastIndexOf('</html>');
  if (endIdx >= 0) html = html.slice(0, endIdx + '</html>'.length);

  // 4. Remove LaTeX delimiters and common commands → plain text
  html = html
    .replace(/\\begin\{[^}]+\}/g, '')
    .replace(/\\end\{[^}]+\}/g, '')
    .replace(/\\frac\s*\{([^}]*)\}\s*\{([^}]*)\}/g, '($1)/($2)')
    .replace(/\\sqrt\s*\{([^}]*)\}/g, '√($1)')
    .replace(/\\sum/g, 'Σ')
    .replace(/\\int/g, '∫')
    .replace(/\\prod/g, 'Π')
    .replace(/\\infty/g, '∞')
    .replace(/\\pi/g, 'π')
    .replace(/\\theta/g, 'θ')
    .replace(/\\lambda/g, 'λ')
    .replace(/\\mu/g, 'μ')
    .replace(/\\alpha/g, 'α')
    .replace(/\\beta/g, 'β')
    .replace(/\\gamma/g, 'γ')
    .replace(/\\Delta/g, 'Δ')
    .replace(/\\cdot/g, '·')
    .replace(/\\times/g, '×')
    .replace(/\\div/g, '÷')
    .replace(/\\leq/g, '≤')
    .replace(/\\geq/g, '≥')
    .replace(/\\neq/g, '≠')
    .replace(/\\approx/g, '≈')
    .replace(/\\to/g, '→')
    .replace(/\\text\s*\{([^}]*)\}/g, '$1')
    .replace(/\\\(|\\\)/g, '')
    .replace(/\\\[|\\\]/g, '')
    .replace(/\$\$([^$]+)\$\$/g, '$1')
    .replace(/\$([^$\n]+)\$/g, '$1')
    // remove any leftover LaTeX commands like \foo or \foo{...}
    .replace(/\\[a-zA-Z]+\s*\{([^}]*)\}/g, '$1')
    .replace(/\\[a-zA-Z]+/g, '');

  // 5. Remove markdown artifacts that escaped into HTML text nodes.
  // Only target obvious leftovers — avoid touching attribute values.
  html = html
    .replace(/```[a-zA-Z]*\n?/g, '')
    .replace(/```/g, '')
    .replace(/(^|\n)#{1,6}\s+/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/(?<!\w)\*([^*\n]+)\*(?!\w)/g, '$1')
    .replace(/`([^`\n]+)`/g, '$1');

  // 6. If model returned no <html>, wrap minimally
  if (!/<html[\s>]/i.test(html)) {
    html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Document</title><style>@page{size:A4;margin:1in}body{font-family:"Times New Roman",serif;font-size:12pt;line-height:1.5;color:#000}h1{text-align:center}p{text-align:justify}</style></head><body>${html}</body></html>`;
  }

  return html;
}

const MATH_INSTRUCTIONS = `
**CRITICAL - LaTeX Math Formatting (ALWAYS follow these rules exactly):**

For inline math, use single dollar signs: $x^2 + y^2 = r^2$

For block/display math, use double dollar signs on SEPARATE LINES:

$$
\\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}
$$

For matrices, ALWAYS use \\begin{bmatrix}...\\end{bmatrix} inside $$ $$:

$$
A = \\begin{bmatrix} 1 & 2 \\\\ 3 & 4 \\end{bmatrix}
$$

Rules:
- Use \\frac{a}{b} for fractions (NOT a/b in complex expressions)
- Use \\sqrt{x} for square roots
- Use \\cdot for multiplication dots
- Use \\\\ for new rows in matrices (ALWAYS double backslash)
- Use & to separate columns in matrices
- NEVER output raw LaTeX source like \\begin or \\frac as plain text
- ALL math must be inside $ or $$ delimiters
- NEVER use \\( \\) or \\[ \\] - ONLY use $ and $$
- Use \\text{} for text inside math environments
- Use \\operatorname{} for multi-letter operators
- Properly nest braces: \\frac{\\sqrt{x^2+1}}{2}`;

const getSystemPrompt = (type: string) => {
  switch (type) {
    case 'quiz':
      return `You are Tanoedu AI Quiz Generator. Generate quiz questions in valid JSON format only.
Return ONLY a JSON array: [{"question": "...", "type": "multiple_choice", "options": ["A","B","C","D"], "correct_answer": "A", "explanation": "..."}]
${MATH_INSTRUCTIONS}`;

    case 'study_plan':
      return `You are Tanoedu AI Study Planner. Create study plans in valid JSON format only.
Return ONLY: {"title": "...", "topics": [{"name": "...", "duration": "...", "description": "...", "completed": false, "resources": ["..."]}], "tips": ["..."], "milestones": ["..."]}`;

    case 'summary':
      return `You are Tanoedu AI Summarizer. Provide clear, comprehensive summaries.\n${MATH_INSTRUCTIONS}`;

    case 'pdf':
      return `You are an advanced HTML-to-PDF document engine in PREMIUM DESIGN + ZERO ERROR + VISUAL INTELLIGENCE MODE.
Generate a COMPLETE, PROFESSIONAL, PRINT-READY HTML document that looks like a high-quality academic/professional report.

CORE PRIORITY: 1) Rendering stability  2) Visual clarity (diagrams + structure)  3) Professional layout  4) Readability  5) Simplicity.
Never prioritize design over correctness — but within safe limits, produce a polished, premium-feeling document.

⚠️ ABSOLUTE OUTPUT RULES:
- Output ONLY raw HTML. Start EXACTLY with <!DOCTYPE html>, end EXACTLY with </html>.
- NO markdown, NO backticks, NO \`\`\`html fences, NO commentary, NO explanations.
- All CSS in ONE <style> tag. No external CSS/JS/fonts/images/CDNs.

🛡️ ERROR PREVENTION (assume any complex feature can break PDF rendering — default to SIMPLE, SAFE, PREDICTABLE):
1. SYNTAX → close every tag, valid nesting, no orphan elements.
2. RENDERING → simplify layout, reduce density, control spacing, avoid overflow.
3. FORMAT MIXING (CRITICAL) → strip all LaTeX/markdown, convert to plain text.
4. STRUCTURAL → uniform sections, consistent hierarchy, even content distribution.
5. PERFORMANCE → lightweight CSS, no heavy tables, no deep nesting.
6. FUTURE-RISK → replace anything that MAY break in any PDF engine with safest alternative.

🚫 FORBIDDEN OUTPUT (STRICT BLOCK):
- NO LaTeX or math markup: \\begin, \\end, \\frac, \\sqrt, \\lambda, \\sum, \\int, \\(, \\), \\[, \\], $, $$.
- NO markdown: #, ##, **, *, \`, \`\`\`, ~~, ---.
- NO <table> elements (convert tabular data to bullet points).
- NO flexbox, grid, float, position:absolute/fixed, transforms, animations.
- NO heavy decorative styling: drop-shadows, gradients, thick colored borders.
- NO images, NO SVG, NO <canvas>, NO external resources, NO JavaScript, NO inline-style overload.

✅ MATH/SYMBOLS — plain text or Unicode only:
- "lambda = 0.5", "E = mc²", "x² + y² = r²", "∫ from 0 to 1 of x² dx = 1/3".
- Allowed: ² ³ ⁿ ₀ ₁ ₂ × ÷ ± ≤ ≥ ≠ ≈ ∞ π θ λ μ Δ Σ ∫ √ → ∈.

📋 TABULAR DATA RULE:
- If data is tabular → convert to BULLET POINTS, never use <table>.

🎨 AUTO DIAGRAM SYSTEM (CRITICAL FEATURE):
Whenever the topic involves a FLOW, PROCESS, RELATIONSHIP, or SYSTEM STRUCTURE, you MUST insert at least one ASCII diagram.
- Use ONLY pure ASCII inside <div class="diagram"><pre>...</pre></div>.
- Allowed glyphs: - | + → ← ↑ ↓ [ ] ( ) / \\ = * and letters/numbers.
- NO SVG, NO canvas, NO images, NO JS — text-based diagrams only.
- Each diagram must be centered, monospace, ≤ 70 columns wide so it never overflows A4.
- Diagrams must visually explain the concept (flowchart, pipeline, hierarchy, cycle).
Examples:
  [ Input ] --> [ Process ] --> [ Output ]
  +--------+    +---------+    +--------+
  | Stage1 |--->| Stage2  |--->| Stage3 |
  +--------+    +---------+    +--------+

💡 HIGHLIGHT BLOCKS:
- For key insights/definitions, wrap in <div class="highlight">...</div>.
- Use sparingly (max 1 per section) to maintain visual rhythm.

🧱 FIXED HTML TEMPLATE (use this exact skeleton, premium typography, A4-safe):
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>{Topic Title}</title>
<style>
@page { size: A4; margin: 1in; }
body { font-family: "Times New Roman", Georgia, serif; font-size: 12pt; line-height: 1.6; color: #111; margin: 0; }
.container { max-width: 100%; }
h1 { text-align: center; font-size: 24pt; margin: 0 0 8px; page-break-after: avoid; letter-spacing: 0.3px; }
.subtitle { text-align: center; font-size: 11pt; color: #555; margin-bottom: 22px; font-style: italic; }
h2 { font-size: 15pt; margin-top: 22px; margin-bottom: 8px; padding-bottom: 4px; border-bottom: 1px solid #ddd; page-break-after: avoid; }
h3 { font-size: 12pt; margin-top: 14px; margin-bottom: 6px; page-break-after: avoid; }
p { text-align: justify; margin: 0 0 10px; orphans: 3; widows: 3; }
ul, ol { margin: 6px 0 12px 22px; }
li { margin-bottom: 5px; }
section { page-break-inside: avoid; margin-bottom: 16px; }
.highlight { background: #f5f5f5; border-left: 4px solid #333; padding: 10px 14px; margin: 14px 0; page-break-inside: avoid; }
.diagram { background: #fafafa; border: 1px solid #ccc; padding: 12px; margin: 14px auto; text-align: center; page-break-inside: avoid; }
.diagram pre { font-family: "Courier New", monospace; font-size: 10pt; white-space: pre; margin: 0; display: inline-block; text-align: left; }
</style>
</head>
<body>
  <h1>{Title}</h1>
  <div class="subtitle">{One-line summary of the document}</div>
  <section><h2>Introduction</h2><p>...</p></section>
  <section><h2>Core Concepts</h2><p>...</p><div class="highlight">...key insight...</div></section>
  <section><h2>Detailed Explanation</h2><p>...</p>
    <div class="diagram"><pre>[ Input ] --> [ Process ] --> [ Output ]</pre></div>
  </section>
  <section><h2>Key Points</h2><ul><li>...</li></ul></section>
  <section><h2>Practical Examples</h2><p>...</p></section>
  <section><h2>Conclusion</h2><p>...</p></section>
</body>
</html>

📐 CONTENT ENGINE — always produce these parts in order:
1. Title  2. Subtitle  3. Introduction  4. Core Concepts  5. Detailed Explanation (with ≥1 diagram)
6. Key Points (bullets)  7. Practical Examples  8. Conclusion

🧠 INTELLIGENT SIMPLIFICATION:
- IF content is complex → simplify.
- IF layout is risky → flatten structure.
- IF formatting is mixed → unify into plain text.
- IF a diagram would exceed 70 cols or look cluttered → simplify it to a single line flow.

🎯 AUTO-OPTIMIZATION:
- Medium-length paragraphs (4–7 sentences). Balance content across ~4–6 pages.
- No overcrowding, no overly short content, smooth reading flow, no repetition.
- Uniform spacing, consistent hierarchy, no visual inconsistency.
- Insert highlight blocks for definitions/key insights; insert diagrams for processes/flows/relationships.

🔁 SELF-VALIDATION LOOP — run before output, repeat until ZERO issues:
✔ No LaTeX  ✔ No $ or \\ commands  ✔ No markdown (#, **, \`\`\`)  ✔ No <table>
✔ No flexbox/grid/float/absolute  ✔ No SVG/canvas/img/script  ✔ All tags closed  ✔ Single <style> block
✔ Uniform structure  ✔ Diagrams ≤ 70 cols  ✔ No overflow risk  ✔ Consistent formatting
If ANY violation → REMOVE or SIMPLIFY. If unsure → use simplest version.

FAIL-SAFE: Never attempt risky formatting. Output must render correctly across ALL PDF engines.

Return ONLY the complete HTML document.`;

    case 'vision':
      return `You are Tanoedu AI Vision Assistant. Analyze images in detail: describe elements, extract text, explain math/diagrams with LaTeX, interpret charts.\n${MATH_INSTRUCTIONS}`;

    case 'resume':
      return `You are Tanoedu AI Resume Writer. Use strong action verbs, quantify achievements, keep bullets concise, use industry keywords. Return only improved text.`;

    default:
      return `You are Tanoedu AI, an advanced academic assistant. Help with learning, homework, research, exams, writing, code, and math.

**Formatting:** Use **bold**, \`code blocks\`, headings (#), bullet points, tables, > blockquotes.

${MATH_INSTRUCTIONS}

Be helpful, accurate, educational. ALWAYS complete your response fully.`;
  }
};

async function callModel(modelName: string, messages: any[], stream: boolean, temperature: number, maxTokens: number = 8192) {
  console.log(`Calling model: ${modelName} with maxTokens: ${maxTokens}`);
  
  return await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://tanoedu-ai.web.app',
      'X-Title': 'Tanoedu AI',
    },
    body: JSON.stringify({
      model: modelName,
      messages,
      stream,
      max_tokens: maxTokens,
      temperature,
    }),
  });
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      messages, 
      model = 'gpt-oss-120b', 
      stream = true, 
      type = 'chat',
      images = [],
      maxTokens = 8192,
      pdfOptions = null
    } = await req.json();

    if (!OPENROUTER_API_KEY) {
      throw new Error('OPENROUTER_API_KEY is not configured');
    }

    const hasImages = images && images.length > 0;
    const isVisionRequest = hasImages || type === 'vision';
    
    let primaryModel: string;
    let fallbackModels: typeof FREE_TEXT_MODELS;
    
    if (isVisionRequest) {
      primaryModel = MODEL_ALIASES[model] && VISION_MODEL_IDS.includes(model) 
        ? MODEL_ALIASES[model] 
        : 'google/gemma-4-31b-it:free';
      fallbackModels = FREE_VISION_MODELS;
    } else {
      primaryModel = MODEL_ALIASES[model] || MODEL_ALIASES['gpt-oss-120b'];
      fallbackModels = FREE_TEXT_MODELS;
    }

    let systemPrompt = getSystemPrompt(type);
    
    if (pdfOptions) {
      systemPrompt += `\n\nDocument Requirements:
- Title: ${pdfOptions.title || 'Untitled'}
- Type: ${pdfOptions.type}
- Style: ${pdfOptions.style}
- Length: ${pdfOptions.length === 'short' ? '3-4 sections' : pdfOptions.length === 'medium' ? '4-5 sections' : '5-6 sections'}
Generate COMPLETE content. Never truncate.`;
    }

    const temperature = type === 'quiz' || type === 'study_plan' ? 0.3 : type === 'pdf' ? 0.3 : 0.7;
    const tokenLimit = pdfOptions?.length === 'long' ? 24000 : type === 'pdf' ? 12000 : maxTokens > 8192 ? maxTokens : 16384;

    let fullMessages: any[];
    
    if (hasImages) {
      const lastUserMessage = messages[messages.length - 1];
      const previousMessages = messages.slice(0, -1);
      
      const imageContent = images.map((img: string) => ({
        type: 'image_url',
        image_url: { url: img }
      }));
      
      fullMessages = [
        { role: 'system', content: systemPrompt },
        ...previousMessages,
        {
          role: 'user',
          content: [
            { type: 'text', text: lastUserMessage.content },
            ...imageContent
          ]
        }
      ];
    } else {
      fullMessages = [
        { role: 'system', content: systemPrompt },
        ...messages,
      ];
    }

    // PDF mode MUST be non-streaming so we can run the sanitizer over full HTML.
    const effectiveStream = type === 'pdf' ? false : stream;
    let response = await callModel(primaryModel, fullMessages, effectiveStream, temperature, tokenLimit);
    let usedModel = primaryModel;
    let attempts = 1;

    if (!response.ok) {
      console.log(`Primary model ${primaryModel} failed (${response.status}), trying fallbacks...`);
      
      for (const fallbackModel of fallbackModels) {
        if (fallbackModel.name === primaryModel) continue;
        attempts++;
        console.log(`Fallback: ${fallbackModel.name}`);
        response = await callModel(fallbackModel.name, fullMessages, effectiveStream, temperature, tokenLimit);
        usedModel = fallbackModel.name;
        
        if (response.ok) break;
        if (attempts >= 5) break;
      }
    }

    if (!response.ok) {
      const error = await response.text();
      console.error('All models failed:', response.status, error);
      
      return new Response(JSON.stringify({ 
        error: response.status === 429 
          ? 'All AI models are busy. Please try again in a moment.' 
          : 'AI service temporarily unavailable. Please try again.',
      }), {
        status: response.status === 429 ? 429 : 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (effectiveStream) {
      const headers = new Headers(corsHeaders);
      headers.set('Content-Type', 'text/event-stream');
      headers.set('X-Model-Used', usedModel);
      headers.set('X-Vision-Mode', String(isVisionRequest));
      return new Response(response.body, { headers });
    } else {
      const data = await response.json();

      if (type === 'pdf' && data?.choices?.[0]?.message?.content) {
        const raw = data.choices[0].message.content as string;
        let cleaned = sanitizePdfHtml(raw);
        cleaned = autoBalanceSections(cleaned, pdfOptions?.length || 'medium');

        let validation = validatePdfHtml(cleaned);
        let usedFallback = false;
        if (!validation.ok) {
          console.warn('[pdf] validation failed:', validation.reasons);
          // Extract plain text from the raw model output for the fallback
          const stripped = raw
            .replace(/<style[\s\S]*?<\/style>/gi, '')
            .replace(/<script[\s\S]*?<\/script>/gi, '')
            .replace(/<[^>]+>/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
          cleaned = buildFallbackHtml(pdfOptions?.title || 'Document', stripped);
          usedFallback = true;
          validation = validatePdfHtml(cleaned);
        }

        data.choices[0].message.content = cleaned;
        (data as any).pdf_meta = {
          used_fallback: usedFallback,
          validation_reasons: validation.reasons,
          balanced_for_length: pdfOptions?.length || 'medium',
        };

        // Persist sanitized HTML in the user's documents table for replay/debug.
        try {
          const authHeader = req.headers.get('Authorization') || '';
          const jwt = authHeader.replace(/^Bearer\s+/i, '');
          const supabaseUrl = Deno.env.get('SUPABASE_URL');
          const supabaseAnon = Deno.env.get('SUPABASE_ANON_KEY');
          if (jwt && supabaseUrl && supabaseAnon) {
            const userRes = await fetch(`${supabaseUrl}/auth/v1/user`, {
              headers: { Authorization: `Bearer ${jwt}`, apikey: supabaseAnon },
            });
            if (userRes.ok) {
              const u = await userRes.json();
              if (u?.id) {
                await fetch(`${supabaseUrl}/rest/v1/documents`, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    apikey: supabaseAnon,
                    Authorization: `Bearer ${jwt}`,
                    Prefer: 'return=minimal',
                  },
                  body: JSON.stringify({
                    user_id: u.id,
                    title: pdfOptions?.title || 'Generated PDF',
                    file_type: usedFallback ? 'pdf-html-fallback' : 'pdf-html',
                    content: cleaned,
                  }),
                });
              }
            }
          }
        } catch (e) {
          console.error('[pdf] failed to store document:', e);
        }
      }

      return new Response(JSON.stringify({ ...data, model_used: usedModel }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  } catch (error) {
    console.error('Chat function error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error',
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
